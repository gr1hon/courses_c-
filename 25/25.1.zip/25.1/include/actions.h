#pragma once
#include <iostream>

using namespace std;

struct point{
    double x{};
    double y{};
};

bool equals(point point1, point point2){
    return(point1.x == point2.x && point1.y == point2.y);
}

void input(point& point){
    cout << "Enter the point" << endl;
    cin >> point.x >> point.y;
}

void output(point& point){
    cout << "(" << point.x << ", " << point.y << ")";
}