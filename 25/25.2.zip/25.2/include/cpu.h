#pragma once
#include "ram.h"
#include <iostream>

using namespace std;

void compute();
