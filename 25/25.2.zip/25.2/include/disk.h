#pragma once

void save();

void load();