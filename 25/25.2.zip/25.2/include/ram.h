#pragma once
#include <vector>

using namespace std;

void write(vector<int> vec);

vector<int> read();