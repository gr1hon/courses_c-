#include "cpu.h"
#include "ram.h"

void compute(){
    int res = 0;
    vector<int> vec{};
    vec = read();
    for (int i = 0; i < vec.size(); ++i) {
        res += vec[i];
    }
    cout << res << endl;
}
