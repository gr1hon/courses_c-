#include "disk.h"
#include "ram.h"
#include <vector>
#include <fstream>
#include <iostream>


using namespace std;

string data_path = "..\\data.txt";

void save(){
    vector<int> vec(8);
    vec = read();
    ofstream file(data_path);
    if (file.is_open()){
        for (int i = 0; i < vec.size(); ++i) {
            file.write((char*) &(vec[i]), sizeof (vec[i]));
        }
    } else
        cerr << "Saving error!" << endl;
}

void load(){
    vector<int> vec(8);
    ifstream file(data_path);
    if (file.is_open()){
        for (int i = 0; i < vec.size(); ++i) {
            file.read((char*) &(vec[i]), sizeof (vec[i]));
        }
    } else
        cerr << "Reading error!" << endl;
    write(vec);
}