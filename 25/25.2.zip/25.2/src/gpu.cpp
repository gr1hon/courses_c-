#include "gpu.h"
#include "ram.h"
#include <iostream>
#include <vector>

using namespace std;

void print(){
    vector<int> data;
    data = read();
    for (int i = 0; i < data.size(); ++i) {
        cout << data[i] << " ";
    }
    cout << endl;
}