#include "kbd.h"
#include<iostream>
#include <vector>
#include "ram.h"
using namespace std;

void input(){
    vector<int> vec;
    int x;
    cout << "Enter 8 numbers to write them to RAM:" << endl;
    for (int i = 0; i < 8; ++i) {
        cin >> x;
        vec.push_back(x);
    }
    write(vec);
}
