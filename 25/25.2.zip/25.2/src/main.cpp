#include <iostream>
#include "cpu.h"
#include "gpu.h"
#include "disk.h"
#include "kbd.h"

using namespace std;

int main() {
    string command;
    while (command != "exit"){
        cout << "Enter the command(sum, save, load, input, display or exit):" << endl;
        cin >> command;
        if (command == "sum")
            compute();
        else if (command == "save")
            save();
        else if (command == "load")
            load();
        else if (command == "input")
            input();
        else if (command == "display")
            print();
        else if (command == "exit"){

        }
        else
            cerr << "Unknown command!" << endl;
    }
}
