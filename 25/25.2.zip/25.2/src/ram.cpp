#include <iostream>
#include <fstream>
#include <vector>
#include "ram.h"

using namespace std;

string path = "..\\buffer.bin";

void write(vector<int> vec){
    ofstream file(path, ios::binary);
    if (file.is_open()){
        for (int i = 0; i < vec.size(); ++i) {
            file.write((char*) &(vec[i]), sizeof (vec[i]));
        }
    } else
        cerr << "Error writing to RAM" << endl;
}

vector<int> read(){
    vector<int> vec(8);
    ifstream file(path, ios::binary);
    if (file.is_open()){
        for (int i = 0; i < vec.size(); ++i) {
            file.read((char*) &(vec[i]), sizeof (vec[i]));
        }
    } else
        cerr << "Error reading RAM" << endl;
    return vec;
}