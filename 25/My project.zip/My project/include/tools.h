#pragma once
#include "actions.h"
#include <iostream>

using namespace std;

void scalpel(point start, point end){
    cout << "Successfully made an incision with coordinates: ";
    output(start);
    cout << " and ";
    output(end);
    cout << endl;
}

void hemostat(point point){
    cout << "Successfully clamped at the point: ";
    output(point);
    cout << endl;
}

void tweezers(point point){
    cout << "Successfully applied tweezers to the point: ";
    output(point);
    cout << endl;
}

void suture(point start, point end){
    cout << "successfully made a seam with coordinates: ";
    output(start);
    cout << " and ";
    output(end);
    cout << endl;
}