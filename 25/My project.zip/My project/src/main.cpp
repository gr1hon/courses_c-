#include "../include/tools.h"
#include <iostream>

using namespace std;

int main(){
    string command;
    do{
        cout << "Enter the command(scalpel, hemostat, tweezers, or suture):" << endl;
        cin >> command;
        if (command != "scalpel")
            cout << "First command must be 'scalpel'!" << endl;
    } while(command != "scalpel");

    point point1; point point2;
    point start1; point start2;
    point end1; point end2;

    do {
        if (command == "scalpel"){
            input(point1);
            input(point2);
            scalpel(point1, point2);
            start1 = point1;
            start2 = point2;
        } else if (command == "hemostat"){
            input(point1);
            hemostat(point1);
        } else if (command == "tweezers"){
            input(point1);
            tweezers(point1);
        } else if (command == "suture"){
            input(point1);
            input(point2);
            suture(point1, point2);
            end1 = point1;
            end2 = point2;
        } else
            cout << "Unknown command" << endl;
        if (!(equals(end1, start1) && equals(end2, start2))){
            cout << "Enter the command(scalpel, hemostat, tweezers, or suture):" << endl;
            cin >> command;
        }
    } while(!(equals(end1, start1) && equals(end2, start2)));
    cout << "Operation completed successfully!" << endl;
}