#include <QApplication>
#include <QtGui/QtGui>
#include <QFileDialog>
#include <QGraphicsBlurEffect>
#include <QGraphicsScene>
#include <QGraphicsPixmapItem>
#include <QDir>
#include <QPainter>

#include <QGraphicsView>
#include <QVBoxLayout>
#include <QPushButton>
#include <QLabel>
#include <QSlider>

#include <QFuture>
#include <QtConcurrent/QtConcurrent>

QImage blurImage(QImage source, int blurRadius)
{
    if (source.isNull()) return QImage();
    QGraphicsScene scene;
    QGraphicsPixmapItem item;
    item.setPixmap(QPixmap::fromImage(source));

    auto *blur = new QGraphicsBlurEffect;
    blur->setBlurRadius(blurRadius);
    item.setGraphicsEffect(blur);
    scene.addItem(&item);
    QImage result(source.size(), QImage::Format_ARGB32);
    result.fill(Qt::transparent);
    QPainter painter(&result);
    scene.render(&painter, QRectF(), QRectF(0, 0, source.width(), source.height()));
    return result;
}

//void processSingleImage(QString source, QString dest, int radius){
//    auto blured = blurImage(QImage(source), radius);
//    blured.save(dest);
//}

int main(int argc, char** argv)
{
    QApplication app(argc, argv);

    QWidget window;
    QVBoxLayout vbox(&window);

    auto* label = new QLabel(&window);
    auto* slider = new QSlider(&window);
    slider->setOrientation(Qt::Horizontal);
    slider->setMaximum(10);
    slider->setMinimum(0);
    auto* openButton = new QPushButton("Open", &window);

    vbox.addWidget(label);
    vbox.addWidget(slider);
    vbox.addWidget(openButton);

    QString filePath;

    QObject::connect(openButton, &QPushButton::clicked, [&filePath, &label]
                    {
                        filePath = QFileDialog::getOpenFileName(nullptr,
                                                                 "Open .jpg file",
                                                                 "../images",
                                                                 "jpg files (*.jpg)");
                        label->setPixmap(QPixmap::fromImage(QImage(filePath)));
                    });

    QImage image(filePath);

    QObject::connect(slider, &QSlider::valueChanged, [&image, &label, &slider]()
        {
            QImage bluredImage = blurImage(image, slider->value());
            if(!bluredImage.isNull()){
                label->setPixmap(QPixmap::fromImage(bluredImage).scaled(
                                    label->height(),
                                    label->width(),
                                    Qt::KeepAspectRatio));
            }
        });
    window.show();
    window.move(300,50);
    return app.exec();
}
